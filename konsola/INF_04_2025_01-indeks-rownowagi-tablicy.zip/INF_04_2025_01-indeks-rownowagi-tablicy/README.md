# Algorytm indeks równowagi tablicy
![{64BD78E0-DE72-47D8-9B83-793BF448AF0C}](https://github.com/user-attachments/assets/d521549c-d632-4ec6-ad0b-e1567b172f65)
![{6009F0A7-CF2B-4A6C-85AC-793459D6E6EB}](https://github.com/user-attachments/assets/52c2901a-d873-4a72-9238-ebdb369ea80b)
![obraz](https://github.com/user-attachments/assets/c494fb7c-c9c5-41ff-90b4-ed2b335f05c5)
